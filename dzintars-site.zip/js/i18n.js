(function () {
  "use strict";

  var STORAGE_KEY = "dz_lang";
  var DEFAULT_LANG = "lv";

  var DICT = {
    lv: {
      "app.title": "Dzintars — sludinājumi Latvijā",
      "nav.signin": "Ienākt",
      "search.placeholder": "Meklēt visos reģionos…",
      "home.foryou.title": "Kartītes tev",
      "home.foryou.sub": "Pēc taviem meklējumiem un pilsētas",
      "home.recommended": "Ieteiktie sludinājumi",
      "cat.realestate": "Nekustamais īpašums",
      "cat.transport": "Transports",
      "cat.parts": "Rezerves daļas",
      "cat.clothes": "Apģērbs, apavi",
      "cat.services": "Pakalpojumi",
      "cat.jobs": "Darbs",
      "cat.business": "Bizness 360",
      "cat.home": "Mājai un dārzam",
      "tab.search": "Meklēt",
      "tab.favorites": "Izlase",
      "tab.listings": "Sludinājumi",
      "tab.messages": "Ziņas",
      "tab.profile": "Profils",
      "listing.placeholder.title": "Sludinājuma nosaukums parādīsies šeit",
      "listing.placeholder.price": "Cena",
      "listing.placeholder.location": "Pilsēta",
      "auth.title": "Sveicināti!",
      "auth.subtitle": "Ienāc vai reģistrējies, lai turpinātu",
      "auth.google": "Turpināt ar Gmail",
      "auth.emailLabel": "E-pasts vai tālrunis",
      "auth.emailPlaceholder": "vards@epasts.lv",
      "auth.continue": "Turpināt",
      "auth.or": "vai",
      "auth.terms": "Turpinot, jūs piekrītat lietošanas noteikumiem un privātuma politikai.",
      "auth.demoNotice": "Šī ir tikai maketa forma — reģistrācija vēl nedarbojas."
    },
    ru: {
      "app.title": "Dzintars — объявления в Латвии",
      "nav.signin": "Войти",
      "search.placeholder": "Поиск во всех регионах…",
      "home.foryou.title": "Карточки для вас",
      "home.foryou.sub": "По вашим поискам и городу",
      "home.recommended": "Рекомендуемые объявления",
      "cat.realestate": "Недвижимость",
      "cat.transport": "Транспорт",
      "cat.parts": "Запчасти",
      "cat.clothes": "Одежда, обувь",
      "cat.services": "Услуги",
      "cat.jobs": "Работа",
      "cat.business": "Бизнес 360",
      "cat.home": "Для дома и дачи",
      "tab.search": "Поиск",
      "tab.favorites": "Избранное",
      "tab.listings": "Объявления",
      "tab.messages": "Сообщения",
      "tab.profile": "Профиль",
      "listing.placeholder.title": "Здесь появится название объявления",
      "listing.placeholder.price": "Цена",
      "listing.placeholder.location": "Город",
      "auth.title": "Добро пожаловать!",
      "auth.subtitle": "Войдите или зарегистрируйтесь, чтобы продолжить",
      "auth.google": "Продолжить с Gmail",
      "auth.emailLabel": "Почта или телефон",
      "auth.emailPlaceholder": "imya@pochta.lv",
      "auth.continue": "Продолжить",
      "auth.or": "или",
      "auth.terms": "Продолжая, вы принимаете условия использования и политику конфиденциальности.",
      "auth.demoNotice": "Это форма-макет — регистрация пока не работает."
    },
    en: {
      "app.title": "Dzintars — classifieds in Latvia",
      "nav.signin": "Sign in",
      "search.placeholder": "Search all regions…",
      "home.foryou.title": "Picked for you",
      "home.foryou.sub": "Based on your searches and city",
      "home.recommended": "Recommended listings",
      "cat.realestate": "Real estate",
      "cat.transport": "Vehicles",
      "cat.parts": "Spare parts",
      "cat.clothes": "Clothes, shoes",
      "cat.services": "Services",
      "cat.jobs": "Jobs",
      "cat.business": "Business 360",
      "cat.home": "Home & garden",
      "tab.search": "Search",
      "tab.favorites": "Favorites",
      "tab.listings": "Listings",
      "tab.messages": "Messages",
      "tab.profile": "Profile",
      "listing.placeholder.title": "Listing title will appear here",
      "listing.placeholder.price": "Price",
      "listing.placeholder.location": "City",
      "auth.title": "Welcome!",
      "auth.subtitle": "Sign in or sign up to continue",
      "auth.google": "Continue with Gmail",
      "auth.emailLabel": "Email or phone",
      "auth.emailPlaceholder": "name@email.com",
      "auth.continue": "Continue",
      "auth.or": "or",
      "auth.terms": "By continuing you agree to the terms of use and privacy policy.",
      "auth.demoNotice": "This is a mockup form only — sign-up isn't wired up yet."
    }
  };

  function getLang() {
    var lang = DEFAULT_LANG;
    try {
      var stored = localStorage.getItem(STORAGE_KEY);
      if (stored && DICT[stored]) lang = stored;
    } catch (e) { /* storage unavailable */ }
    return lang;
  }

  function applyTranslations(lang) {
    var dict = DICT[lang] || DICT[DEFAULT_LANG];
    document.documentElement.setAttribute("lang", lang);

    document.querySelectorAll("[data-i18n]").forEach(function (el) {
      var key = el.getAttribute("data-i18n");
      if (dict[key]) el.textContent = dict[key];
    });

    document.querySelectorAll("[data-i18n-placeholder]").forEach(function (el) {
      var key = el.getAttribute("data-i18n-placeholder");
      if (dict[key]) el.setAttribute("placeholder", dict[key]);
    });

    var titleEl = document.querySelector("title[data-i18n]");
    if (titleEl && dict[titleEl.getAttribute("data-i18n")]) {
      document.title = dict[titleEl.getAttribute("data-i18n")];
    }
  }

  window.Dzintars = window.Dzintars || {};
  window.Dzintars.i18n = {
    STORAGE_KEY: STORAGE_KEY,
    dict: DICT,
    getLang: getLang,
    t: function (key) {
      var dict = DICT[getLang()] || DICT[DEFAULT_LANG];
      return dict[key] || key;
    },
    apply: function () { applyTranslations(getLang()); }
  };

  document.addEventListener("DOMContentLoaded", function () {
    applyTranslations(getLang());
  });
})();
