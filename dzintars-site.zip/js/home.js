(function () {
  "use strict";

  // Placeholder icon shown inside every empty listing photo slot.
  var PHOTO_ICON = '<svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">' +
    '<rect x="3" y="5" width="18" height="14" rx="2" stroke="currentColor" stroke-width="1.6"/>' +
    '<circle cx="8.5" cy="10" r="1.5" stroke="currentColor" stroke-width="1.6"/>' +
    '<path d="M3 16L8 12L12 15L16 11L21 16" stroke="currentColor" stroke-width="1.6"/>' +
    '</svg>';

  var LISTING_COUNT = 8; // fixed grid size for this static placeholder feed

  function buildCard() {
    var article = document.createElement("article");
    article.className = "listing-card is-empty";
    article.innerHTML =
      '<div class="listing-photo">' + PHOTO_ICON + '</div>' +
      '<div class="listing-body">' +
        '<div class="listing-title"></div>' +
        '<div class="listing-price"></div>' +
        '<div class="listing-location"></div>' +
      '</div>';
    return article;
  }

  document.addEventListener("DOMContentLoaded", function () {
    var grid = document.getElementById("listing-grid");
    if (!grid) return;
    for (var i = 0; i < LISTING_COUNT; i++) {
      grid.appendChild(buildCard());
    }
  });
})();
