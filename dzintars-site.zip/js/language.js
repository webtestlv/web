(function () {
  "use strict";

  var STORAGE_KEY = "dz_lang"; // "lv" | "ru" | "en"

  var COPY = {
    lv: {
      heading: "Izvēlieties valodu",
      subtext: "Jūs varēsiet to mainīt vēlāk iestatījumos",
      label: "Pieejamās valodas",
      continueBtn: "Turpināt",
      footnote: "Izvēle tiks saglabāta šajā ierīcē"
    },
    ru: {
      heading: "Выберите язык",
      subtext: "Вы сможете изменить его позже в настройках",
      label: "Доступные языки",
      continueBtn: "Продолжить",
      footnote: "Выбор будет сохранён на этом устройстве"
    },
    en: {
      heading: "Choose your language",
      subtext: "You can change this later in settings",
      label: "Available languages",
      continueBtn: "Continue",
      footnote: "Your choice will be saved on this device"
    }
  };

  // If a language was already chosen before, skip straight to home.
  var existing = null;
  try { existing = localStorage.getItem(STORAGE_KEY); } catch (e) { /* storage unavailable */ }
  if (existing && COPY[existing]) {
    window.location.replace("home.html");
    return;
  }

  document.addEventListener("DOMContentLoaded", function () {
    var buttons = Array.prototype.slice.call(document.querySelectorAll(".lang-btn"));
    var continueBtn = document.getElementById("lang-continue");
    var heading = document.getElementById("lang-heading");
    var subtext = document.getElementById("lang-subtext");
    var labelEl = document.querySelector("[data-i18n-label]");
    var footnoteEl = document.querySelector("[data-i18n-footnote]");
    var selected = "lv";

    function applyCopy(langCode) {
      var c = COPY[langCode];
      heading.textContent = c.heading;
      subtext.textContent = c.subtext;
      labelEl.textContent = c.label;
      continueBtn.textContent = c.continueBtn;
      footnoteEl.textContent = c.footnote;
      document.documentElement.setAttribute("lang", langCode);
    }

    function selectLang(code) {
      selected = code;
      buttons.forEach(function (btn) {
        var isMatch = btn.getAttribute("data-lang") === code;
        btn.classList.toggle("is-selected", isMatch);
        btn.setAttribute("aria-pressed", isMatch ? "true" : "false");
      });
      applyCopy(code);
    }

    buttons.forEach(function (btn) {
      btn.addEventListener("click", function () {
        selectLang(btn.getAttribute("data-lang"));
      });
    });

    continueBtn.addEventListener("click", function () {
      try { localStorage.setItem(STORAGE_KEY, selected); } catch (e) { /* storage unavailable */ }
      window.location.href = "home.html";
    });

    selectLang(selected);
  });
})();
